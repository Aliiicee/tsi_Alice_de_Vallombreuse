package com.example.phone.models;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;
import javax.persistence.Table;

@Entity
@Table(name = "Toy")
public class TestModel {
    @Id
    @Getter
    @Column(name = "id")
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "tutorial_generator")
    private int id;
    @Getter @Setter
    @Column(name = "brand")
    private String brand;
    @Getter @Setter @Column(name = "model")
    private String model;
    @Getter @Setter @Column(name = "price")
    private double price;
    public TestModel() {
    }
    public TestModel(int id, String brand, String model, double price) {
        this.id = id;
        this.brand = brand;
        this.model = model;
        this.price = price;
    }
}

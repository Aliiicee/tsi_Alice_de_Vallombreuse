CREATE TABLE Toy(id INT PRIMARY KEY AUTO_INCREMENT,
                 brand VARCHAR(255), model VARCHAR(255), price double );

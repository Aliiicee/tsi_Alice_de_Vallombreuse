CREATE TABLE Toy(id INT PRIMARY KEY AUTO_INCREMENT,
                 brand VARCHAR(255), model VARCHAR(255), price double );



INSERT INTO Toy(brand, model, price) VALUES('Iphone', '14', 1000.00);
INSERT INTO Toy(brand, model, price) VALUES('Iphone', '5s', 100.00);
INSERT INTO Toy(brand, model, price) VALUES('Samsung', 'Galaxy s10', 400.00);
INSERT INTO Toy(brand, model, price) VALUES('Samsung', 'Galaxy s6', 120.00);
-- INSERT INTO Toy(name, age, price) VALUES('Los Angeles',22, 22.0);
-- INSERT INTO Toy(name, age, price) VALUES('New York', 23, 23.0);
-- INSERT INTO Toy(name, age, price) VALUES('New York', 24, 24.0);